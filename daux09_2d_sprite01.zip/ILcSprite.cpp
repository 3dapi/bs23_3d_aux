// Implementation of the CLcSprite class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>


#include "ILcSprite.h"


#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }




class CLcSprite : public ILcSprite
{
protected:
	LPDIRECT3DDEVICE9		m_pDev;		// Device
	LPDIRECT3DSTATEBLOCK9	m_pStCur;	// Current State Block
	LPDIRECT3DSTATEBLOCK9	m_pStSpt;	// Sprite State Block
	
public:
	CLcSprite();
	virtual ~CLcSprite();

	INT		Create(LPDIRECT3DDEVICE9 pDev);

	virtual INT Draw(void* pTx0, const RECT* pRcDrw=NULL, const FLOAT* pvcPos=NULL, DWORD Color=0xFFFFFFFF);
};



CLcSprite::CLcSprite()
{
	m_pDev		= NULL;

	m_pStCur	= NULL;
	m_pStSpt	= NULL;
}



CLcSprite::~CLcSprite()
{
	SAFE_RELEASE(	m_pStCur	);
	SAFE_RELEASE(	m_pStSpt	);
}



INT CLcSprite::Create(LPDIRECT3DDEVICE9 pDev)
{
	HRESULT hr=-1;

	m_pDev = (LPDIRECT3DDEVICE9)pDev;


	DWORD	vCur[128]={0};

	// Save Current State
	m_pDev->GetRenderState( D3DRS_FOGENABLE,			&vCur[ 0]);
	m_pDev->GetRenderState( D3DRS_LIGHTING,				&vCur[ 1]);
	m_pDev->GetRenderState( D3DRS_ZENABLE,				&vCur[ 2]);

	m_pDev->GetRenderState( D3DRS_ALPHATESTENABLE,		&vCur[ 3]);
	m_pDev->GetRenderState( D3DRS_ALPHABLENDENABLE,		&vCur[ 4]);
	m_pDev->GetRenderState( D3DRS_SRCBLEND,				&vCur[ 5]);
	m_pDev->GetRenderState( D3DRS_DESTBLEND,			&vCur[ 6]);

	m_pDev->GetSamplerState( 0, D3DSAMP_MINFILTER,		&vCur[ 7]);
	m_pDev->GetSamplerState( 0, D3DSAMP_MAGFILTER,		&vCur[ 8]);
	m_pDev->GetSamplerState( 1, D3DSAMP_MINFILTER,		&vCur[ 9]);
	m_pDev->GetSamplerState( 1, D3DSAMP_MAGFILTER,		&vCur[10]);

	m_pDev->GetTextureStageState( 0, D3DTSS_COLORARG1,	&vCur[11]);
	m_pDev->GetTextureStageState( 0, D3DTSS_COLORARG2,	&vCur[12]);
	m_pDev->GetTextureStageState( 0, D3DTSS_COLOROP,	&vCur[13]);

	m_pDev->GetTextureStageState( 0, D3DTSS_ALPHAARG1,	&vCur[14]);
	m_pDev->GetTextureStageState( 0, D3DTSS_ALPHAARG2,	&vCur[15]);
	m_pDev->GetTextureStageState( 0, D3DTSS_ALPHAOP,	&vCur[16]);

	m_pDev->GetTextureStageState( 1, D3DTSS_COLORARG1,	&vCur[17]);
	m_pDev->GetTextureStageState( 1, D3DTSS_COLORARG2,	&vCur[18]);
	m_pDev->GetTextureStageState( 1, D3DTSS_COLOROP,	&vCur[19]);

	m_pDev->GetTextureStageState( 1, D3DTSS_ALPHAARG1,	&vCur[20]);
	m_pDev->GetTextureStageState( 1, D3DTSS_ALPHAARG2,	&vCur[21]);
	m_pDev->GetTextureStageState( 1, D3DTSS_ALPHAOP,	&vCur[22]);



	// Record State Block
	m_pDev->BeginStateBlock();

	m_pDev->SetRenderState( D3DRS_FOGENABLE,			FALSE );
	m_pDev->SetRenderState( D3DRS_LIGHTING,				FALSE );
	m_pDev->SetRenderState( D3DRS_ZENABLE,				FALSE);

	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE,		TRUE);
	m_pDev->SetRenderState( D3DRS_SRCBLEND,				D3DBLEND_SRCALPHA );
	m_pDev->SetRenderState( D3DRS_DESTBLEND,			D3DBLEND_INVSRCALPHA );

	m_pDev->SetSamplerState( 0, D3DSAMP_MINFILTER,		D3DTEXF_NONE);
	m_pDev->SetSamplerState( 0, D3DSAMP_MAGFILTER,		D3DTEXF_NONE);

	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1,	D3DTA_TEXTURE);
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2,	D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,	D3DTOP_MODULATE);

	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1,	D3DTA_TEXTURE);
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG2,	D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,	D3DTOP_MODULATE);

	// End Record and Create State Block
	m_pDev->EndStateBlock(&m_pStSpt);



	m_pDev->BeginStateBlock();
	m_pDev->SetRenderState( D3DRS_FOGENABLE,			vCur[ 0]);
	m_pDev->SetRenderState( D3DRS_LIGHTING,				vCur[ 1]);
	m_pDev->SetRenderState( D3DRS_ZENABLE,				vCur[ 2]);

	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE,		vCur[ 3]);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE,		vCur[ 4]);
	m_pDev->SetRenderState( D3DRS_SRCBLEND,				vCur[ 5]);
	m_pDev->SetRenderState( D3DRS_DESTBLEND,			vCur[ 6]);

	m_pDev->SetSamplerState( 0, D3DSAMP_MINFILTER,		vCur[ 7]);
	m_pDev->SetSamplerState( 0, D3DSAMP_MAGFILTER,		vCur[ 8]);
	m_pDev->SetSamplerState( 1, D3DSAMP_MINFILTER,		vCur[ 9]);
	m_pDev->SetSamplerState( 1, D3DSAMP_MAGFILTER,		vCur[10]);

	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1,	vCur[11]);
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2,	vCur[12]);
	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,	vCur[13]);

	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1,	vCur[14]);
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG2,	vCur[15]);
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,	vCur[16]);

	m_pDev->SetTextureStageState( 1, D3DTSS_COLORARG1,	vCur[17]);
	m_pDev->SetTextureStageState( 1, D3DTSS_COLORARG2,	vCur[18]);
	m_pDev->SetTextureStageState( 1, D3DTSS_COLOROP,	vCur[19]);

	m_pDev->SetTextureStageState( 1, D3DTSS_ALPHAARG1,	vCur[20]);
	m_pDev->SetTextureStageState( 1, D3DTSS_ALPHAARG2,	vCur[21]);
	m_pDev->SetTextureStageState( 1, D3DTSS_ALPHAOP,	vCur[22]);
	m_pDev->EndStateBlock(&m_pStCur);

	return 0;
}



INT CLcSprite::Draw(void* pTx0, const RECT* pRcDrw, const FLOAT* pvcPos, DWORD Color)
{
	LPDIRECT3DTEXTURE9	pTex0= (LPDIRECT3DTEXTURE9)	pTx0;

	if(NULL == pTex0)
		return -1;


	// ���ǽ��� Width, Height�� �����´�.
	D3DSURFACE_DESC dsc;
	pTex0->GetLevelDesc(0, &dsc);
	FLOAT fImgW = FLOAT(dsc.Width);		// Width of Surface
	FLOAT fImgH = FLOAT(dsc.Height);	// Height of Surface

	// Draw Region Left, Top, Width, Height
	FLOAT	fDrwL=  0;
	FLOAT	fDrwT=  0;
	FLOAT	fDrwW=800;
	FLOAT	fDrwH=600;


	D3DXVECTOR2	pos(0,0);
	D3DXCOLOR	dColor = Color;
	D3DXVECTOR2	uv0(0,0);
	D3DXVECTOR2	uv1(1,1);


	// Draw Region Width, Height
	if(pRcDrw)
	{
		fDrwL = FLOAT(pRcDrw->left);
		fDrwT = FLOAT(pRcDrw->top);
		fDrwW = FLOAT(pRcDrw->right - pRcDrw->left);
		fDrwH = FLOAT(pRcDrw->bottom- pRcDrw->top );
	}

	// Setup Draw Position
	if(pvcPos)
	{
		pos.x = pvcPos[0];
		pos.y = pvcPos[1];
	}

	// Setup UV
	uv0.x = (fDrwL +     0)/fImgW;
	uv1.x = (fDrwL + fDrwW)/fImgW;

	uv0.y = (fDrwT +     0)/fImgH;
	uv1.y = (fDrwT + fDrwH)/fImgH;

	
	// Setup Vertices
	struct TVtxRHWUV1
	{
		FLOAT		p[4];
		DWORD		d;
		FLOAT		u, v;
	} pVtx[4] =
	{
		{pos.x +     0, pos.y +     0,  0,  1,  dColor,   uv0.x,  uv0.y},
		{pos.x + fDrwW, pos.y +     0,  0,  1,  dColor,   uv1.x,  uv0.y},
		{pos.x + fDrwW, pos.y + fDrwH,  0,  1,  dColor,   uv1.x,  uv1.y},
		{pos.x +     0, pos.y + fDrwH,  0,  1,  dColor,   uv0.x,  uv1.y},
	};


	// Rendering 2D

	// Save Current State
	m_pStCur->Capture();

	// Apply 2D Sprite State
	m_pStSpt->Apply();
	
	m_pDev->SetTexture(0, pTex0);
	m_pDev->SetFVF(D3DFVF_XYZRHW|D3DFVF_DIFFUSE|D3DFVF_TEX1);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, pVtx, sizeof(TVtxRHWUV1) );
	m_pDev->SetTexture(0, NULL);

	m_pStCur->Apply();

	return 0;
}





INT LcxCreateSprite(ILcSprite** pOut, void* pd3dDevice)
{
	CLcSprite*	pObj=NULL;

	pObj = new CLcSprite;

	if(FAILED(pObj->Create((LPDIRECT3DDEVICE9)pd3dDevice)))
	{
		delete pObj;
		return -1;
	}

	*pOut = pObj;
	return 0;
}

